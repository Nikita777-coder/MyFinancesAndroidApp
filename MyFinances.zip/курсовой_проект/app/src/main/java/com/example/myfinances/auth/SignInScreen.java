package com.example.myfinances.auth;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.myfinances.R;

public class SignInScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in_screen);
//        // Создаем родительский LinearLayout
//        LinearLayout parentLayout = new LinearLayout(this);
//        parentLayout.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
//        parentLayout.setOrientation(LinearLayout.VERTICAL);
//        parentLayout.setBackground(getResources().getDrawable(R.drawable.auth_background));
//        parentLayout.setGravity(Gravity.CENTER);
//        setContentView(parentLayout);
//
//        // Добавляем TextView - заголовок
//        TextView titleTextView = new TextView(this);
//        titleTextView.setLayoutParams(new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
//        titleTextView.setText(R.string.title);
//        titleTextView.setTextColor(getResources().getColor(R.color.white));
//        titleTextView.setTextSize(36);
//        titleTextView.setTypeface(null, Typeface.BOLD);
//        titleTextView.setGravity(Gravity.LEFT);
//        titleTextView.setPadding(30, 0, 0, 0);
//        parentLayout.addView(titleTextView);
//
//        // Добавляем первый блок с кнопками "Sign In" и "Sign Up"
//        RelativeLayout signInSignUpLayout = new RelativeLayout(this);
//        LinearLayout.LayoutParams signInSignUpLayoutParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 55);
//        signInSignUpLayoutParams.setMargins(20, 10, 20, 0);
//        signInSignUpLayout.setLayoutParams(signInSignUpLayoutParams);
//        parentLayout.addView(signInSignUpLayout);
//
//        // Добавляем поля для ввода публичных данных
//        RelativeLayout publicDataLayout = new RelativeLayout(this);
//        LinearLayout.LayoutParams publicDataLayoutParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 55);
//        publicDataLayoutParams.setMargins(20, 20, 20, 0);
//        publicDataLayout.setLayoutParams(publicDataLayoutParams);
//        publicDataLayout.setBackground(getResources().getDrawable(R.drawable.rectangle_with_bottom_border));
//        parentLayout.addView(publicDataLayout);
//
//        // Добавляем поля для ввода пароля
//        RelativeLayout passwordLayout = new RelativeLayout(this);
//        LinearLayout.LayoutParams passwordLayoutParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 55);
//        passwordLayoutParams.setMargins(20, 20, 20, 0);
//        passwordLayout.setLayoutParams(passwordLayoutParams);
//        passwordLayout.setBackground(getResources().getDrawable(R.drawable.rectangle_with_bottom_border));
//        parentLayout.addView(passwordLayout);
//
//        // Добавляем текст "Forgot password?"
//        TextView forgotPasswordTextView = new TextView(this);
//        LinearLayout.LayoutParams forgotPasswordLayoutParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
//        forgotPasswordLayoutParams.setMargins(0, 10, 10, 0);
//        forgotPasswordTextView.setLayoutParams(forgotPasswordLayoutParams);
//        forgotPasswordTextView.setGravity(Gravity.END);
//        forgotPasswordTextView.setText(R.string.forgot_password);
//        forgotPasswordTextView.setTextColor(getResources().getColor(R.color.white));
//        forgotPasswordTextView.setTextSize(12);
//        forgotPasswordTextView.setTypeface(null, Typeface.BOLD);
//        parentLayout.addView(forgotPasswordTextView);
    }
}